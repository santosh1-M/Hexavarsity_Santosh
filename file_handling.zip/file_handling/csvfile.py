
import pandas as pd
import csv  

file_path = r"C:\Users\91701\Downloads\excel(Sheet1).csv"

data = [
    ["Name", "Age", "Department"],
    ["Alice", 23, "IT"],
    ["Bob", 28, "HR"],
    ["Charlie", 26, "Finance"]
]

with open(file_path, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerows(data)

with open(file_path, mode='r', newline='', encoding='utf-8') as file:
    reader = csv.reader(file)
    for row in reader:
        print(row)

with open("C:\\Users\\91701\\Desktop\\sample.txt","w") as f:
    f.write("welcome to coding new")
with open("C:\\Users\\91701\\Desktop\\sample.txt","r") as f:
        content = f.read()
        print(content)
with open("C:\\Users\\91701\\Desktop\\sample.txt","a") as f:
    f.write(" vnsbvnbnfb")
with open("C:\\Users\\91701\\Desktop\\sample.txt","r") as f:
        content = f.read()
        print(content)


    

from openpyxl import Workbook, load_workbook


file_path = r"C:\Users\91701\Desktop\student_data_test1.xlsx"

wb = Workbook()
ws = wb.active

for i in range(1, 1000001):
    ws.append([f"Row {i}", f"Value {i}"])

wb.save(file_path)

wb = load_workbook(r"C:\Users\91701\Desktop\student_data_test1.xlsx", read_only=True) 
ws = wb.active

for row in ws.iter_rows(min_row=1, max_row=10, max_col=2, values_only=True):
    print(row)  


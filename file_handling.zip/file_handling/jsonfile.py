import json

data = {
    "name": "Alice",
    "age": 25,
    "department": "IT",
    "skills": ["Python", "SQL", "Machine Learning"],
    "active": True
}


file_path = r"C:\Users\91701\Desktop\employee.json"

with open(file_path, 'w') as json_file:
    json.dump(data, json_file, indent=4)

print(" JSON file created on Desktop successfully.")

data = {
    "name": "Alice",
    "age": 25,
    "city": "Boston",
    "skills": ["Python", "SQL", "Machine Learning"]
}

with open(file_path, 'w') as file:
    json.dump(data,file, indent=4)  
    
with open(r"C:\Users\91701\Desktop\employee.json","r") as file:
    k=json.load(file)
print(k["skills"])
    
import json

try:
    with open(file_path, 'r') as file:
        data = json.load(file)
except FileNotFoundError:
    print("The file was not found.")
except json.JSONDecodeError:
    print("Invalid JSON format.")

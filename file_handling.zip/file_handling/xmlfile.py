from bs4 import BeautifulSoup

xml_content = """
<data>
    <person>
        <name>John</name>
        <age>30</age>
    </person>
    <student>
        <name>Alice</name>
        <age>25</age>
    </student>
</data>
"""

soup = BeautifulSoup(xml_content, "xml")

with open(r"C:\Users\91701\Desktop\employee.xml", "w", encoding="utf-8") as file:
    file.write(soup.prettify())

with open(r"C:\Users\91701\Desktop\employee.xml", "r", encoding="utf-8") as file:
    soup = BeautifulSoup(file, "xml")
    title = soup.find("name").text
    print(title)


from openpyxl import Workbook, load_workbook

file_path = r"C:\Users\91701\Desktop\student_data_test.xlsx"


wb = Workbook()
sheet = wb.active
sheet.append(["Name", "Age", "Department"])
sheet.append(["Alice", 25, "IT"])
sheet.append(["Bob", 28, "HR"])
wb.save(file_path)

wb = load_workbook(file_path)
sheet = wb.active

for row in sheet.iter_rows(min_row=2, values_only=True):
    name, age, department = row
    print(f"Name: {name}, Age: {age}, Department: {department}")

from openpyxl import Workbook

filepath1=r"C:\Users\91701\Desktop\student_data_test1.xlsx"
wb = Workbook()
ws = wb.active

for i in range(1, 1000001):
    ws.append([f"Row {i}", f"Value {i}"])
    
wb.save(filepath1)

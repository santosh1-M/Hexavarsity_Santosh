
# # print hello world:

# print("hello world")
# n=10
# print(n)
# v="nfkjrnf"

# # using type function:

# a=20.3
# print(type(n),type(a),n,a)
# print(v,type(v))

# # local variables and outer variables
# if(n==10):
#     print("matched")
# else:
#     print("not matched")
# def fun():
#     a=30.0
#     print(a)
# fun()
# print(a)

# #To print datatype

# p="rnjr"
# print(type(p),p)

# kx=19>23
# print(type(kx),kx)

# pp=5+6j
# print(type(pp),pp)

# #if statement 
# val=int(input("Enter number:"))
# if(val%10==0):
#     print(val,"data")
# else:
#     print("pata")

# #using fstring :

# val=int(input("Enter number:"))
# if(val%10==0):
#     print(f"{val} data")
# elif(val%20==0):
#     print("tata")
# else:
#     print("pata")
    

# # checking prime number:

# num = int(input("Enter a number: "))

# if num > 1:
#     for i in range(2, int(num ** 0.5) + 1):
#         if num % i == 0:
#             print(f"{num} is not a prime number.")
#             break
#     else:
#         print(f"{num} is a prime number.")
# else:
#     print(f"{num} is not a prime number.")



# # 1.Check each number in a list and print whether it's even or odd:

# list=[]
# len=int(input("Enter length for list:"))
# for i in range(0,len):
#     list.append(int(input()))
# for i in list:
#     if(i%2==0):
#         print(f"{i} is even")
#     else:
#         print(f"{i} is odd")
# # 

# #2.Use else after a loop to run code only if no break occurred:

# for i in range(1, 4):
#     print(i)
# else:
#     print("loop exexuted")

# 3.Nested If : if x > 10: and if x > 20:

# new=int(input("enter value:"))
# if(new>10):
#     if(new<15):
#         print(f"{new} is greater than 10 and less than 15")
#     else:
#          print(f"{new} is greater than 10 and greater than 15")
# else:
#     print(f"{new} is less than 10 ")   
    
# # 4.Combine multiple conditions in one if: using age,has_license

# new1=int(input("enter value 1:"))
# new2=int(input("enter value 2:"))
# if(new1%2==0 and new2%2==0):
#     print("both are divisible by the 2")
# elif(new1%2==0 or new2%2==0):
#     print("one of the number are divisible by the 2")
# else:
#     print("Numbers are not divisible by 2")

# list=[]
# len=int(input("Enter length for list:"))
# for i in range(0,len):
#     list.append(int(input()))
# for i in list:
#     if(i>18):
#         print(f"{i}able to aplly for licence")
#     else:
#         print(f"{i}5not eligible for licence")

# # 5.factorial of a number:

# val=int(input("Enter number:"))
# product=1
# for i in range(1,val+1):
#     product*=i
# print(product)

# # 6.Recursive function:

# def fact(n):
#     if(n==1 or n==0):
#         return 1
#     else:
#         return n*fact(n-1)
    
# val=int(input("enter value:"))
# print(fact(val))

# # String Functions:

# # Clean and normalize a name:

# name = "   santosh "
# now = name.strip().title() 
# print(now) 


# s = "hello world"
# vowels = sum(s.count(v) for v in "aeiou")
# print(vowels) 
# count=0
# for i in s:
#     if i in "aeiou":
#         count=count+1
# print(count)

# # # Replace digits with '*' using translate():
# import string
# tbl = str.maketrans({d: "^" for d in string.digits})
# print("Phone: 123-456".translate(tbl))  # Phone: ***-***

# # fstring with various formats

# str="santosh"
# print(f"{str.upper()}")
# print(f"{str.title()}")
# print(f"{str.lower()}")
# print(f"{len(str)}")
# print(f"{str.count('s')}")
# print(f"{str.find('s')}")

# #join words

# list=["edbdb","ndfn","nebf"]
# print("-".join(list))

# #while loop

# n=int(input("enter value"))
# while(n>=0):
#     print(n,end=' ')
#     n=n-1

# pattern 

# n=int(input("Enter number:"))
# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print(j,end=' ')
#     print(end='\n')

# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print(i,end=' ')
#     print(end='\n')
    
# for i in range(1,n+1):
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print(end='\n')
    
# for i in range(n,0,-1):
#     for j in range(1,i+1):
#         print(j,end=' ')
#     print(end='\n')

# for i in range(n,0,-1):
#     for j in range(1,i+1):
#         print("A",end=' ')
#     print(end='\n')


# # arrow pattern

# for i in range(1,n+1):
#     for k in range(1,i+1):
#         print(end=' ')
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print(end='\n')
# for i in range(n,0,-1):
#     for k in range(1,i+1):
#         print(end=' ')
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print(end='\n')
# # diamond pattern 

# for i in range(1,n+1):
#     for k in range(i,n+1):
#         print(end=' ')
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print(end='\n')
# for i in range(n,0,-1):
#     for k in range(i,n+1):
#         print(end=' ')
#     for j in range(1,i+1):
#         print("*",end=' ')
#     print(end='\n')

# # brak,continue,pass
# n=int(input("Enter number:"))
# while(n>=0):
#     if(n==2):
#         break
#     print(n)
#     n=n-1
# v=int(input("Enter number2:"))
# while(v>=0):
#     if(v==2):
#         v = v - 1 
#         continue
#     print(v)
#     v=v-1
 
# while(v>=0):
#     if(v==2):
#         pass
#     print(v)
#     v=v-1
    
    
class studentmanager:
    def __init__(self):
        self.students = {}

    def addstudent(self, rollnumber, studentname, marks):
        if rollnumber in self.students:
            print(f"{rollnumber} already exists")
        else:
            self.students[rollnumber] = {"name": studentname, "marks": marks}
            print(f"{rollnumber} is added")

    def get_students(self):
        print(self.students)

    def getstudentsroll(self, rollnumber):
        if rollnumber in self.students:
            print(f"{rollnumber} exists")
        else:
            print(f"{rollnumber} doesn't exist")

    def gettopstudent(self, condition):
        topstudents = [    
            {"rollnumber": rollnumber, "studentname": data["name"], "marks": data["marks"]}
            for rollnumber, data in self.students.items() 
            if data["marks"] >= condition
        ]
        return topstudents

manager = studentmanager()

students_data = [
    {"rollNumber": 1234, "studentname": "Job", "marks": 85},
    {"rollNumber": 2345, "studentname": "Rane", "marks": 74},
    {"rollNumber": 3456, "studentname": "Alice", "marks": 81},
    {"rollNumber": 4567, "studentname": "Hari", "marks": 92},
    {"rollNumber": 4567, "studentname": "Meera", "marks": 68},
   
]

for student in students_data:
    manager.addstudent(student["rollNumber"], student["studentname"], student["marks"])

print("All Students:")
print(manager.get_students())

print("getting students by roll")
print(manager.getstudentsroll(1234))

print("\nTop Students (marks >= 80):")
print(manager.gettopstudent(80))

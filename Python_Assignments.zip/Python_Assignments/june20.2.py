class bankAccount:
    def __init__(self,accholder,balance=0):
        self.accholder=accholder
        self._balance=balance
    
    def deposit(self,amount=0):
        if(amount>0):
            self._balance=self._balance+amount
            print(f"{amount} after added  to balance amount after depositing is {self._balance}")
        else:
            print(f"{amount} deposit amount is invalid")
            
    def checkbalance(self):
        print(f"Balance amount {self._balance} ")
class savingaccount(bankAccount):
    def __init__(self,accholder,account,_balance=0,interest_rate=0.05):
        super().__init__(accholder,_balance)
        self.interest_rate=interest_rate
    def calculateinterest(self):
        interest=self._balance*self.interest_rate
        self._balance=self._balance-interest
        print(f"interest = {interest}")
        print(f"{self._balance} is new balance after interest")

savings = savingaccount("charan", 1000)
savings.deposit(20000)
savings.calculateinterest()
savings.checkbalance()
   

    
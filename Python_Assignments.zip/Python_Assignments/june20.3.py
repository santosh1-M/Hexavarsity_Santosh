class bankAccount:
    def __init__(self,accholder,balance=0):
        self.accholder=accholder
        self._balance=balance
    
    def deposit(self,amount=0,currency="INR"):
        if(amount>0):
            self._balance=self._balance+amount
            print(f"{amount} after added  to balance amount after depositing is {self._balance}")
        else:
            print(f"{amount} deposit amount is invalid")
    def withdraw(self,amount):
        if(amount<self._balance):
            self._balalnce=self._balance - amount
            print(f"amount withdrawn suceessfully of {amount}")
        else:
            print(f"{amount} has less balance than current banace ")
            
class savingaccount(bankAccount):
    def __init__(self, accholder, balance=0, overdraft_limit=1000):
        super().__init__(accholder, balance)
        self.overdraft_limit = overdraft_limit

    def withdraw(self, amount):
        if amount <= self._balance + self.overdraft_limit:
            self._balance -= amount
            print(f"Amount withdrawn is {amount}. Remaining balance: {self._balance}")
        else:
            print(f"Withdrawal of {amount} denied. Overdraft limit exceeded.")


account=bankAccount("santosh",500)
account.deposit(500,"usa")
           
sa = savingaccount("Santosh", 500, overdraft_limit=1000)
sa.withdraw(300)   
sa.withdraw(800)  
sa.withdraw(1000)  


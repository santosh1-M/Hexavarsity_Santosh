class bankAccount:
    def __init__(self,accholder,balance=0):
        self.accholder=accholder
        self._balance=balance
    
    def deposit(self,amount=0):
        if(amount>0):
            self._balance=self._balance+amount
            print(f"{amount} after added  to balance amount after depositing is {self._balance}")
        else:
            print(f"{amount} deposit amount is invalid")
            
    def checkbalance(self):
        print(f"Balance amount {self._balance} ")
    
account=bankAccount("santosh",500)
account.deposit(500)
account.checkbalance()
print(account._balance)


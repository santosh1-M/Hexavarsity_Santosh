# Create a Student class with student_id and student_name, then instantiate and display their values

class rectangle:
    def area(self,length,breadth):
        return length* breadth
rr=rectangle()
length=int(input("Enter length:"))
breadth=int(input("Enter breadth:"))
print(f" the area is {rr.area(length,breadth)}")

# Student Class with Instance Attributes 
# Create a Student class with student_id and student_name, then instantiate and display their values

class student:
    def __init__(self,student_id,student_name):
        self.student_id=student_id
        self.student_name=student_name
    def display(self):
        print(f"studentid: {self.student_id} , studentname: {self.student_name}")
st = student(101,"santosh")
st.display()

# Implement a class with attributes like emp_id, name, salary, department, and method to calculate overtime pay

class employee:
    def __init__(self,emp_id,name,dept,salary=0):
        self.emp_id=emp_id
        self.name=name
        self.dept=dept
        self.salary=salary
    def calculateovertime(self,overtimehour,overtimerate):
        self.salary+=overtimehour*overtimerate
        print(f"{self.emp_id} {self.name} {self.dept} {self.salary}")
em=employee(101,"santosh","cse")
em.calculateovertime(30,300)

# Find the Sum & Product of a List/ Do the String Reversal

class product:
    def __init__(self):
        self.list=[]
    def adddata(self,data):
        self.list.append(data)
    def displaylist(self):
        print(self.list)
    def sumlist(self):
        print(sum(self.list))
    def productlist(self):
        product=1
        for i in self.list:
            product*=i
        print(product)
    def reversestring(self,str):
        print(str[::-1])
p=product()
for i in range(1,6):
    p.adddata(i)
p.displaylist()
p.sumlist()
p.productlist()
p.reversestring("santosh")




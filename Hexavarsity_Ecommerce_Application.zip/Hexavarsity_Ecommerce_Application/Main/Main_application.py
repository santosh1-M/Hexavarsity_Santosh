import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.order_processor_impl import OrderProcessorImpl
from Entity.Customers import Customer
from Entity.product import Product

def menu():
    dao = OrderProcessorImpl()
    cart = {}  
    current_customer = None

    while True:
        print("\n=== E-Commerce Console Menu ===")
        print("1. Register Customer")
        print("2. Create Product")
        print("3. Delete Product")
        print("4. Add to Cart")
        print("5. View Cart")
        print("6. Place Order")
        
        print("7. View Customer Order")
        print("8. Delete Customer")
        print("9. Exit")

        choice = input("Enter your choice (1-9): ")

        if choice == '1':
            print("\n--- Register Customer ---")
            name = input("Enter name: ")
            email = input("Enter email: ")
            password = input("Enter password: ")
            customer = Customer(None, name, email, password)
            dao.create_customer(customer)
            current_customer = customer  

        elif choice == '2':
            print("\n--- Create Product ---")
            name = input("Enter product name: ")
            price = float(input("Enter price: "))
            description = input("Enter description: ")
            stock_quantity = int(input("Enter stock quantity: "))
            product = Product(None, name, price, description, stock_quantity)
            dao.create_product(product)

        elif choice == '3':
            print("\n--- Delete Product ---")
            product_id = int(input("Enter product ID to delete: "))
            dao.delete_product(product_id)

        elif choice == '4':
            print("\n--- Add to Cart ---")
            email = input("Enter your registered email: ")
            product_id = int(input("Enter product ID to add to cart: "))
            quantity = int(input("Enter quantity: "))
            dao.add_to_cart(email, product_id, quantity)

        elif choice == '5':
            print("\n--- View Cart ---")
            email = input("Enter your registered email: ")
            dao.get_all_from_cart(email)


        elif choice == '6':
            print("\n--- Place Order ---")
            email = input("Enter your registered email: ")
            address = input("Enter shipping address: ")
            dao.place_order(email, address)


        elif choice == '7':
            print("\n--- View Customer Order ---")
            email = input("Enter your registered email: ")
            dao.get_orders_by_customer(email)

        elif choice == '8':
            print("\n--- Delete Customer ---")
            customer_id = int(input("Enter customer ID to delete: "))
            success = dao.delete_customer(customer_id)
            if success:
                print("Customer deleted successfully.")
            else:
                print("Failed to delete customer.")

        elif choice == '9':
            print("Exiting application.")
            break

        else:
            print("Invalid choice. Please enter a number from 1 to 8.")

if __name__ == '__main__':
    menu()

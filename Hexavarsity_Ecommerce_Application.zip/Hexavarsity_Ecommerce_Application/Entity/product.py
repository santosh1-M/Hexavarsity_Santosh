class Product:
    def __init__(self, product_id=None, name=None, price=None, description=None, stock_quantity=None):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.description = description
        self.stock_quantity = stock_quantity

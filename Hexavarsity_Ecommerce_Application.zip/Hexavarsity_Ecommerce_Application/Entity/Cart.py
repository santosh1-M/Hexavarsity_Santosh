
class Cart:
    def __init__(self, cart_id=None, customer_id=None, product_id=None, quantity=None):
        self.cart_id = cart_id
        self.customer_id = customer_id
        self.product_id = product_id
        self.quantity = quantity

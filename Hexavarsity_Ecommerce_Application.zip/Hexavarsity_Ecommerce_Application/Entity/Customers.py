class Customer:
    def __init__(self, customer_id=None, name=None, email=None, password=None):
        self.customer_id = customer_id
        self.name = name
        self.email = email
        self.password = password

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import pytest
from unittest.mock import patch, MagicMock

from Entity.product import Product
from Entity.Customers import Customer
from dao.order_processor_impl import OrderProcessorImpl
from Exceptions.Custom_exceptions import (
    ProductCreationException,
    AddToCartException,
    PlaceOrderException
)

@patch("dao.order_processor_impl.get_connection")
def test_create_product_success(mock_get_conn):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_get_conn.return_value = (mock_conn, mock_cursor)

    product = Product(name="Phone", price=15000.0, description="Smartphone", stock_quantity=20)
    impl = OrderProcessorImpl()
    impl.create_product(product)

    mock_cursor.execute.assert_called_once()
    mock_conn.commit.assert_called_once()

@patch("dao.order_processor_impl.get_connection")
def test_add_to_cart_success(mock_get_conn):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_cursor.fetchone.return_value = (1,)  
    mock_get_conn.return_value = (mock_conn, mock_cursor)

    impl = OrderProcessorImpl()
    impl.add_to_cart("santoshmrgn@gmail.com", 101, 3)

    assert mock_cursor.execute.call_count >= 2
    mock_conn.commit.assert_called_once()


@patch("dao.order_processor_impl.get_connection")
def test_place_order_success(mock_get_conn):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()

    mock_cursor.fetchone.side_effect = [(9,), (100.0,)]
    mock_cursor.fetchall.return_value = [(101, 2)]

    mock_get_conn.return_value = (mock_conn, mock_cursor)

    impl = OrderProcessorImpl()
    impl.place_order("santoshmrgn@gmail.com", "Chennai")

    assert mock_cursor.execute.call_count >= 5
    mock_conn.commit.assert_called_once()


@patch("dao.order_processor_impl.get_connection")
def test_add_to_cart_customer_not_found(mock_get_conn):
    mock_conn = MagicMock()
    mock_cursor = MagicMock()
    mock_cursor.fetchone.return_value = None  
    mock_get_conn.return_value = (mock_conn, mock_cursor)

    impl = OrderProcessorImpl()
    with pytest.raises(AddToCartException, match="Customer email not found."):
        impl.add_to_cart("santoshgn@gmail.com", 4, 1)

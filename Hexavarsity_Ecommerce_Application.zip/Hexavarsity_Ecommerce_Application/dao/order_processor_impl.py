import re
from dao.order_processor_repo import OrderProcessorRepository
from Util.db_conn_util import get_connection
from Exceptions.Custom_exceptions import (
    ProductCreationException,
    CustomerCreationException,
    ProductDeletionException,
    CustomerDeletionException,
    AddToCartException,
    RemoveFromCartException,
    GetCartException,
    PlaceOrderException,
    GetOrdersException,
    InvalidPasswordException
)

class OrderProcessorImpl(OrderProcessorRepository):

    @staticmethod
    def validate_password(password):
        if len(password) < 9:
            raise InvalidPasswordException("Password must be at least 9 characters long.")
        if len(re.findall(r"[a-zA-Z]", password)) < 3:
            raise InvalidPasswordException("Password must contain at least 3 letters.")
        if len(re.findall(r"\d", password)) < 2:
            raise InvalidPasswordException("Password must contain at least 2 digits.")
        if len(re.findall(r"[!@#$%^&*(),.?\":{}|<>]", password)) < 1:
            raise InvalidPasswordException("Password must contain at least 1 special character.")

    def create_product(self, product):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            query = """
            INSERT INTO products (name, price, description, stockQuantity)
            VALUES (%s, %s, %s, %s)
            """
            values = (product.name, product.price, product.description, product.stock_quantity)
            cursor.execute(query, values)
            conn.commit()
            print("Product created successfully.")
        except Exception as e:
            raise ProductCreationException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def create_customer(self, customer):
        conn, cursor = None, None
        try:
            OrderProcessorImpl.validate_password(customer.password)
            conn, cursor = get_connection()
            query = """
            INSERT INTO customers (name, email, password)
            VALUES (%s, %s, %s)
            """
            values = (customer.name, customer.email, customer.password)
            cursor.execute(query, values)
            conn.commit()
            print("Customer registered successfully.")
        except Exception as e:
            raise CustomerCreationException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def delete_product(self, product_id):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("DELETE FROM products WHERE product_id = %s", (product_id,))
            conn.commit()
            print("Product deleted.")
        except Exception as e:
            raise ProductDeletionException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def delete_customer(self, customer_id):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("DELETE FROM customers WHERE customer_id = %s", (customer_id,))
            conn.commit()
            print("Customer deleted.")
        except Exception as e:
            raise CustomerDeletionException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def add_to_cart(self, email, product_id, quantity):
        
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            
            cursor.execute("SELECT customer_id FROM customers WHERE email = %s", (email,))
            result = cursor.fetchone()
            if not result:
                raise AddToCartException("Customer email not found.")
            customer_id = result[0]
            cursor.execute("""INSERT INTO cart (customer_id, product_id, quantity)
                           VALUES (%s, %s, %s)
                           ON DUPLICATE KEY UPDATE quantity = quantity + %s
                           """, (customer_id, product_id, quantity, quantity)
                        )

            conn.commit()
            print("Added to cart.")
        except Exception as e:
            raise AddToCartException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def remove_from_cart(self, customer, product_id):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("DELETE FROM cart WHERE customer_id = %s AND product_id = %s",
                           (customer.customer_id, product_id))
            conn.commit()
            print("Removed from cart.")
        except Exception as e:
            raise RemoveFromCartException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()

    def get_all_from_cart(self, email):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT customer_id FROM customers WHERE email = %s", (email,))
            result = cursor.fetchone()
            if not result:
                raise GetCartException("Customer email not found.")
            customer_id = result[0]
            query = """SELECT p.product_id, p.name, p.price, c.quantity
            FROM cart c JOIN products p ON c.product_id = p.product_id WHERE c.customer_id = %s"""
            cursor.execute(query, (customer_id,))
            rows = cursor.fetchall()
            if not rows:
                print("Your cart is empty.")
            else:
                print("Cart Contents:")
            for row in rows:
                print(f"Product ID: {row[0]}, Name: {row[1]}, Price: ₹{row[2]}, Quantity: {row[3]}")
        except Exception as e:
            raise GetCartException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()


    def place_order(self, email, shipping_address):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT customer_id FROM customers WHERE email = %s", (email,))
            result = cursor.fetchone()
            if not result:
                raise PlaceOrderException("Customer with this email not found.")
            customer_id = result[0]

            cursor.execute("""SELECT product_id, quantity FROM cart WHERE customer_id = %s""", (customer_id,))
            cart_items = cursor.fetchall()
            if not cart_items:
                print("Cart is empty.")
                return
            total = 0
            for product_id, qty in cart_items:
                cursor.execute("SELECT price FROM products WHERE product_id = %s", (product_id,))
                price = cursor.fetchone()[0]
                total += price * qty
            cursor.execute("""INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (%s, NOW(), %s, %s)""", (customer_id, total, shipping_address))
            order_id = cursor.lastrowid

            for product_id, qty in cart_items:
                cursor.execute("""INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s, %s, %s)""", (order_id, product_id, qty))

            cursor.execute("DELETE FROM cart WHERE customer_id = %s", (customer_id,))
            conn.commit()
            print(f"Order placed successfully. Order ID: {order_id}")
        except Exception as e:
            if conn: conn.rollback()
            raise PlaceOrderException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()


    def get_orders_by_customer(self, email):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT customer_id FROM customers WHERE email = %s", (email,))
            result = cursor.fetchone()
            if not result:
                print("Customer not found.")
                return
            customer_id = result[0]

            query = """
            SELECT o.order_id, o.order_date, o.total_price, o.shipping_address,
            p.name, oi.quantity
            FROM orders o
            JOIN order_items oi ON o.order_id = oi.order_id
            JOIN products p ON oi.product_id = p.product_id
            WHERE o.customer_id = %s
            ORDER BY o.order_id DESC
            """
            cursor.execute(query, (customer_id,))
            results = cursor.fetchall()

            if not results:
                print("No orders found.")
            else:
                print("Customer Orders:")
                for row in results:
                    print(f"\nOrder ID: {row[0]}, Date: {row[1]}, Total: ₹{row[2]}")
                    print(f"Address: {row[3]}")
                    print(f"  - {row[4]} x {row[5]}")
        except Exception as e:
            raise GetOrdersException(f"Error: {e}")
        finally:
            if cursor: cursor.close()
            if conn: conn.close()
            
    def delete_customer(self, customer_id):
        conn, cursor = None, None
        try:
            conn, cursor = get_connection()
            cursor.execute("SELECT * FROM customers WHERE customer_id = %s", (customer_id,))
            if not cursor.fetchone():
                print("Customer does not exist.")
                return False

            cursor.execute("SELECT * FROM orders WHERE customer_id = %s", (customer_id,))
            if cursor.fetchone():
                print("Cannot delete customer with existing orders.")
                return False
            
            cursor.execute("DELETE FROM customers WHERE customer_id = %s", (customer_id,))
            conn.commit()
            return True

        except Exception as e:
            if conn:
                conn.rollback()
            print(f"Error deleting customer: {e}")
            return False

        finally:
            if cursor:
                cursor.close()
            if conn:
                conn.close()

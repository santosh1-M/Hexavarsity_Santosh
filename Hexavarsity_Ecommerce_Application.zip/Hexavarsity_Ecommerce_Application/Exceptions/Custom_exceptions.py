
class ProductCreationException(Exception):
    def __init__(self, message="Failed to create product."):
        super().__init__(message)

class CustomerCreationException(Exception):
    def __init__(self, message="Failed to create customer."):
        super().__init__(message)

class ProductDeletionException(Exception):
    def __init__(self, message="Failed to delete product."):
        super().__init__(message)

class CustomerDeletionException(Exception):
    def __init__(self, message="Failed to delete customer."):
        super().__init__(message)

class AddToCartException(Exception):
    def __init__(self, message="Failed to add item to cart."):
        super().__init__(message)

class RemoveFromCartException(Exception):
    def __init__(self, message="Failed to remove item from cart."):
        super().__init__(message)

class GetCartException(Exception):
    def __init__(self, message="Failed to retrieve cart items."):
        super().__init__(message)

class PlaceOrderException(Exception):
    def __init__(self, message="Failed to place order."):
        super().__init__(message)

class GetOrdersException(Exception):
    def __init__(self, message="Failed to retrieve orders."):
        super().__init__(message)

class InvalidPasswordException(Exception):
    def __init__(self, message="Invalid password format."):
        super().__init__(message)

class CustomerNotFoundException(Exception):
    pass

class ProductNotFoundException(Exception):
    pass

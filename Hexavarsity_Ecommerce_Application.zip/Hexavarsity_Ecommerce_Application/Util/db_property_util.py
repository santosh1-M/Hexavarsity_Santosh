import configparser

def get_property_values(DB):
    config = configparser.ConfigParser()
    config.read(DB)
    return {
        'host': config['DB']['host'],
        'port': int(config['DB']['port']),
        'user': config['DB']['user'],
        'password': config['DB']['password'],
        'database': config['DB']['database']
    }

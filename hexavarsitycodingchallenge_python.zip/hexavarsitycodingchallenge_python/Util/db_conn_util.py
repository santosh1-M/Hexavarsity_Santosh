
import mysql.connector
from Util.db_property_util import get_property_values

def get_connection():
    db_config = get_property_values('util/db.properties')
    connection = mysql.connector.connect(
        host=db_config['host'],
        port=db_config['port'],
        user=db_config['user'],
        password=db_config['password'],
        database=db_config['database']
    )
    return connection

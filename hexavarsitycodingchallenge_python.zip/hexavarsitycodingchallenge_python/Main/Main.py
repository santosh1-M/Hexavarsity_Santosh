import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.IOrderManagementRepository import Mainprocessor
from Entity.User import User
from Entity.Product import product

def order_management():
    dao = Mainprocessor()
    current_user = None

    while True:
        print("\n=== Order Management System ===")
        print("1. Create User")
        print("2. Create Product")
        print("3. Create order")
        print("4. Cancel Order")
        print("5. Get All Products")
        print("6. Get Order by User")
        print("7. Exit")

        choice = input("Enter your choice (1-6): ")

        if choice == '1':
            print("\n--- Create User ---")
            name = input("Enter name: ")
            email = input("Enter email: ")
            password = input("Enter password: ")
            user = User(None, name, email, password)
            dao.create_user(user)
            current_user = user

        elif choice == '2':
            print("\n--- Create Product ---")
            name = input("Enter product name: ")
            description = input("Enter description: ")
            price = float(input("Enter price: "))
            stock_quantity = int(input("Enter stock quantity: "))
            typ = input("Enter type: ")
            prod = product(None, name, description, price,stock_quantity,typ)
            dao.create_product(prod)
            
        elif choice == '3':
            print("\n--- Create Order ---")
            productlist = []
            while True:
                print("Enter prodcut to insert product list:")
                str=input("Enter yes/no: ")
                if(str=='yes'):
                    name = input("Enter product name: ")
                    description = input("Enter description: ")
                    price = float(input("Enter price: "))
                    stock_quantity = int(input("Enter stock quantity: "))
                    typ = input("Enter type: ")
                    prod = product(productid=None,productname=name,description=description,price=price,quantityinstock=stock_quantity,type=typ
                        )
                    productlist.append(prod)
                else:
                    break
            print("To check whether the user is present or not")
            print("\n--- user details ---")
            id=int(input("Enter userid"))
            name = input("Enter name: ")
            email = input("Enter email: ")
            password = input("Enter password: ")
            user = User(id, name, email, password)
            dao.create_order(user,productlist)
        elif choice == '4':
            print("\n--- Cancel Order ---")
            order_id = int(input("Enter order ID to cancel: "))
            dao.cancel_order(order_id)

        elif choice == '5':
            print("\n--- Get All Products ---")
            dao.get_all_products()

        elif choice == '6':
            print("\n--- Get Order by User ---")
            user_id=int(input("user_id: "))
            dao.get_orders_by_user(user_id)
                
        elif choice == '7':
            print("Exiting Order Management System.")
            break

        else:
            print("Invalid input. Please enter a number from 1 to 6.")

if __name__ == '__main__':
    order_management()

from abc import ABC, abstractmethod

class OrderProcessorRepository(ABC):

    @abstractmethod
    def create_order(self, user, productlist):
        pass

    @abstractmethod
    def cancel_order(self, order_id):
        pass

    @abstractmethod
    def create_product(self, product):
        pass

    @abstractmethod
    def create_user(self, user):
        pass

    @abstractmethod
    def get_all_products(self):
        pass

    @abstractmethod
    def get_orders_by_user(self, user_id):
        pass

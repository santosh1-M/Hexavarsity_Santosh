from .Ioorderprocessorrepo import OrderProcessorRepository
from Util.db_conn_util import get_connection
import datetime
class Mainprocessor(OrderProcessorRepository):

    def create_user(self, user):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM user WHERE user_id = %s", (user.userId,))
            count = cursor.fetchone()[0]
            if count == 0:
                cursor.execute(
                    "INSERT INTO user (user_id, username, password, role) VALUES (%s, %s, %s, %s)",
                    (user.userId, user.username, user.password, user.role)
                )
                connection.commit()
                print("New user created successfully.")
            else:
                print("User already exists.")
        except Exception as e:
            print("Error in create_user:", e)
        finally:
            cursor.close()
            connection.close()

    def create_order(self, user, productlist):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT COUNT(*) FROM user WHERE user_id = %s", (user.userId,))
            count = cursor.fetchone()[0]
            orderid = 0
            if count == 0:
                cursor.execute(
                    "INSERT INTO user (user_id, username, password, role) VALUES (%s, %s, %s, %s)",
                    (user.userId, user.username, user.password, user.role)
                )
                for product in productlist:
                    cursor.execute(
                        "INSERT INTO orders (order_id, user_Id,total_price) VALUES (%s, %s, %s)",
                        (orderid, user.userId, product.price * product.quantityinstock)
                    )
                    orderid += 1
                print("New user inserted.")
            else:
                for product in productlist:
                    cursor.execute(
                        "INSERT INTO orders (order_id, user_id, total_price) VALUES (%s, %s, %s)",
                        (orderid, user.userId, product.price * product.quantityinstock)
                    )
                    orderid += 1
                connection.commit()
            print("Order created successfully.")
        except Exception as e:
            print("Error in create_order:", e)
        finally:
            cursor.close()
            connection.close()

    def create_product(self, product):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute(
                "INSERT INTO product (product_name, description, price, quantity_in_stock, type) VALUES (%s, %s, %s, %s, %s)",
                (product.productname, product.description, product.price, product.quantityinstock, product.type)
            )
            connection.commit()
            print("Product created successfully.")
        except Exception as e:
            print("Error in create_product:", e)
        finally:
            cursor.close()
            connection.close()

    def cancel_order(self, order_id):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("DELETE FROM orders WHERE order_id = %s", (order_id,))
            connection.commit()
            print(f"Order {order_id} cancelled successfully.")
        except Exception as e:
            print("Error in cancel_order:", e)
        finally:
            cursor.close()
            connection.close()

    def get_all_products(self):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM product")
            rows = cursor.fetchall()
            print("\nAll Products")
            for row in rows:
                print(f"ID: {row[0]}, Name: {row[1]}, Description: {row[2]}, Price: {row[3]}, Stock: {row[4]}, Type: {row[5]}")
        except Exception as e:
            print("Error in get_all_products:", e)
        finally:
            cursor.close()
            connection.close()

    def get_orders_by_user(self, user_id):
        try:
            connection = get_connection()
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM orders WHERE user_id = %s ", (user_id,))
            orders = cursor.fetchall()
            if orders:
                print(f"\nOrders for User ID {user_id}")
                for order in orders:
                    print(f"Order ID: {order[0]}, user_id: {order[1]}, Total: {order[2]}")
            else:
                print(f"No orders found for User ID: {user_id}")
        except Exception as e:
            print("Error in get_orders_by_user:", e)
        finally:
            cursor.close()
            connection.close()

from .product import Product 

class Clothing(Product):
    def __init__(self, size=None, color=None):
        self.size = size
        self.color = color



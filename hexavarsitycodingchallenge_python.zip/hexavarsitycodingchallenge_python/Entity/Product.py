
# creating product class:

class product:
    def __init__(self,productid=None,productname=None,description=None,price=None,quantityinstock=None,type=None):
        self.productid=productid
        self.productname=productname
        self.description=description
        self.price=price
        self.quantityinstock=quantityinstock
        self.type=type
    
    #getter
    def get_productId(self):
        return self.productId

    def get_productName(self):
        return self.productName

    def get_description(self):
        return self.description

    def get_price(self):
        return self.price

    def get_quantityInStock(self):
        return self.quantityInStock

    def get_type(self):
        return self.type

    # Setters
    def set_productId(self, productId):
        self.productId = productId

    def set_productName(self, productName):
        self.productName = productName

    def set_description(self, description):
        self.description = description

    def set_price(self, price):
        self.price = price

    def set_quantityInStock(self, quantityInStock):
        self.quantityInStock = quantityInStock

    def set_type(self, type):
        self.type = type
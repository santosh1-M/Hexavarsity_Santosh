from datetime import datetime

class Order:
    def __init__(self, order_id=None,user_id=None, total_price=None):
        self.order_id = order_id                   
        self.user_id = user_id               
        self.total_price = total_price                
         
class User:
    def __init__(self, userId=None, username=None, password=None, role=None):
        self.userId = userId
        self.username = username
        self.password = password
        self.role = role 
from .product import Product
class Electronics(Product):
    def __init__(self,brand=None,warrantyperiod=None):
        self.brand=brand
        self.warrantyperiod=warrantyperiod
        